from .KPIWidget import KPIWidget

__all__ = [
    "KPIWidget"
]